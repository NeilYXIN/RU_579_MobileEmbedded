# Readme
### Data:
**./train:** Training data for the SVM model.
**./test:** Test data for the SVM model.
**./\*.npy, ./\*.txt:** Intermediate results in training and testing SVM model.

### Codes:
**./capture_data.py:** Capture sensor readings from GPIO.
**./classify_svm.py:** Train an SVM model.
**./test_framebyframe.py**