import numpy as np
import scipy.io
import os
import math
import random
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold,StratifiedKFold
from sklearn import svm
from sklearn import metrics
import pickle
from joblib import dump, load
import csv

nFeature = 3
nSimples = 100
nFrames = 50
gesture1 = 20
gesture2 = 40
gesture3 = 60
gesture4 = 80
gesture5 = 100


realtimeDataSape =(nFrames, nFeature)
trainDatashape =(nSimples, nFeature * nFrames)
labelshape =(nSimples)

realtimeData = np.zeros(realtimeDataSape, dtype=np.float32)
trainData = np.zeros(trainDatashape, dtype=np.float32)
labelData = np.zeros(labelshape, dtype=np.float32)

class gestureRC(object):
    clf = None

    def medfilt (self, x, k):
        """Apply a length-k median filter to a 1D array x.
        Boundaries are extended by repeating endpoints.
        """
        assert k % 2 == 1, "Median filter length must be odd."
        assert x.ndim == 1, "Input must be one-dimensional."
        k2 = (k - 1) // 2
        y = np.zeros ((len (x), k), dtype=x.dtype)
        y[:,k2] = x
        for i in range (k2):
            j = k2 - i
            y[j:,i] = x[:-j]
            y[:j,i] = x[0]
            y[:-j,-(i+1)] = x[j:]
            y[-j:,-(i+1)] = x[-1]
        return np.median (y, axis=1)

    def meanfilt (self, x, k):
        """Apply a length-k median filter to a 1D array x.
        Boundaries are extended by repeating endpoints.
        """
        assert k % 2 == 1, "Median filter length must be odd."
        assert x.ndim == 1, "Input must be one-dimensional."
        k2 = (k - 1) // 2
        y = np.zeros ((len (x), k), dtype=x.dtype)
        y[:,k2] = x
        for i in range (k2):
            j = k2 - i
            y[j:,i] = x[:-j]
            y[:j,i] = x[0]
            y[:-j,-(i+1)] = x[j:]
            y[-j:,-(i+1)] = x[-1]
        return np.mean(y, axis=1)

    def print_train_data(self):
        for row in trainData:
            for col in row:
                print(col, end='')
            print ;

    def print_label_data(self):
        index = 0
        for row in labelData:
            print(index, row)
            index += 1
        print ;

    def create_label(self):
        labelData[0:gesture1] = 0
        labelData[gesture1:gesture2] = 1
        labelData[gesture2:gesture3] = 2
        labelData[gesture3:gesture4] = 3
        labelData[gesture4:gesture5] = 4

        np.save("label.npy", labelData)
        np.savetxt("label.txt",labelData)

    def read_csv(self):
        simpe_cnt = 0
        frame_cnt = 0

        for i in range(0, 20):
            data = np.array([])
            with open('courseProjData/swipeRight_'+ format(i, '02d') + '.csv', newline='') as csvfile:
                spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
                # medfilt(data[:,1],3)
                index = 0
                for row in spamreader:
                    row = row[0].split(',')
                    row[0] = float(row[0])
                    row[1] = float(row[1])
                    row[2] = float(row[2])

                    trainData[simpe_cnt][0 + 3 * index] = row[0]
                    trainData[simpe_cnt][1 + 3 * index] = row[1]
                    trainData[simpe_cnt][2 + 3 * index] = row[2]
                    index += 1


                simpe_cnt += 1



        for i in range(0, 20):
            data = np.array([])
            with open('courseProjData/swipeLeft_'+ format(i, '02d') + '.csv', newline='') as csvfile:
            # with open('courseProjData/swipeRight_'+ format(i, '02d') + '.csv', newline='') as csvfile:
                spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
                index = 0
                for row in spamreader:
                    row = row[0].split(',')
                    row[0] = float(row[0])
                    row[1] = float(row[1])
                    row[2] = float(row[2])
                    print(index)

                    trainData[simpe_cnt][0 + 3 * index] = row[0]
                    trainData[simpe_cnt][1 + 3 * index] = row[1]
                    trainData[simpe_cnt][2 + 3 * index] = row[2]
                    index += 1

                simpe_cnt += 1


        for i in range(0, 20):
            data = np.array([])
            with open('courseProjData/swipeForward_'+ format(i, '02d') + '.csv', newline='') as csvfile:
                spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
                index = 0
                for row in spamreader:
                    row = row[0].split(',')
                    row[0] = float(row[0])
                    row[1] = float(row[1])
                    row[2] = float(row[2])

                    trainData[simpe_cnt][0 + 3 * index] = row[0]
                    trainData[simpe_cnt][1 + 3 * index] = row[1]
                    trainData[simpe_cnt][2 + 3 * index] = row[2]
                    index += 1

                simpe_cnt += 1

        index = 0
        for i in range(0, 20):
            data = np.array([])
            with open('courseProjData/swipeBackward_'+ format(i, '02d') + '.csv', newline='') as csvfile:
            # with open('courseProjData/swipeRight_'+ format(i, '02d') + '.csv', newline='') as csvfile:
                spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
                index = 0
                for row in spamreader:
                    row = row[0].split(',')
                    row[0] = float(row[0])
                    row[1] = float(row[1])
                    row[2] = float(row[2])

                    trainData[simpe_cnt][0 + 3 * index] = row[0]
                    trainData[simpe_cnt][1 + 3 * index] = row[1]
                    trainData[simpe_cnt][2 + 3 * index] = row[2]
                    index += 1

                simpe_cnt += 1


        for i in range(0, 20):
            data = np.array([])
            with open('courseProjData/swipeEmpty_'+ format(i, '02d') + '.csv', newline='') as csvfile:
            # with open('courseProjData/swipeRight_'+ format(i, '02d') + '.csv', newline='') as csvfile:
                spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
                index = 0
                for row in spamreader:
                    row = row[0].split(',')
                    row[0] = float(row[0])
                    row[1] = float(row[1])
                    row[2] = float(row[2])

                    trainData[simpe_cnt][0 + 3 * index] = row[0]
                    trainData[simpe_cnt][1 + 3 * index] = row[1]
                    trainData[simpe_cnt][2 + 3 * index] = row[2]
                    index += 1

                simpe_cnt += 1
        np.save("trainDataSet.npy", trainData)
        np.savetxt("trainDataSet.txt",trainData)

    # K-fold cross validation, K=num_Fold
    def cross_validation(self, X, y, num_Fold):
        # Define the split - into k folds
        kf = StratifiedKFold(n_splits=num_Fold, shuffle=False);

        # a list that stores the accuracy of each fold to calculate overall accuracy
        accus=[];

        # Predefine the sum of all confusion matrix
        big_conf_mat=np.zeros((len(set(y)),len(set(y))));
        # Calculate the accuracy for each fold
        for train_index, test_index in kf.split(X,y):
            # train/test split
            train_index=np.array(train_index);
            test_index=np.array(test_index);
            X=np.array(X);
            y=np.array(y);
            X_train, X_test = X[train_index], X[test_index];
            y_train, y_test = y[train_index], y[test_index];

            # Fit the SVM model, kernel function: linear
            clf = svm.SVC(kernel='linear').fit(X_train, y_train);
            # Predict on the test data
            y_pred = clf.predict(X_test);

            # Generate confusion matrix for this fold
            conf_mat=confusion_matrix(y_test, y_pred, );
            print(conf_mat);

            # Sum the overall confusion matrix
            big_conf_mat=big_conf_mat+conf_mat;

            # Calculate the accuracy and append to the list
            accus.append(metrics.accuracy_score(y_test, y_pred));
            print("Accuracy:",accus[-1],'\n');

        # Print the sum of each fold's confusion matrix
        print('SumConfMat:');
        print(big_conf_mat);
        # Print the overall accuracy
        print("CV Accuracy: %0.2f (+/- %0.2f)" % (np.mean(accus), np.std(accus) * 2),'\n');

    def shuffle_in_unison_scary1(self, arr_1, arr_2):
        rng_state = np.random.get_state()
        np.random.shuffle(arr_1)
        np.random.set_state(rng_state)
        np.random.shuffle(arr_2)

    def shuffle_in_unison_scary2(self, arr_1):
        rng_state = np.random.get_state()
        np.random.shuffle(arr_1)


    def processData(self):
        self.read_csv()
        self.print_train_data()
        self.create_label()
        self.print_label_data()

    def train(self):
        # load data
        X_train = np.load("trainDataSet.npy")
        y_train = np.load("label.npy")
        print("data loaded")

        self.shuffle_in_unison_scary1(X_train, y_train)

        clf = svm.SVC(kernel='linear').fit(X_train, y_train); # Train training set using svm
        print("training completed")
        dump(clf, 'gesture.joblib')

    def inference(self):
        # load data
        clf = load('gesture.joblib')

        test_data = np.load("trainDataSet.npy")
        labeld = np.load("label.npy")
        self.shuffle_in_unison_scary1(test_data, labeld)

        label_index =0
        for X_test in test_data:
            # print (X_test)
            y_pred = clf.predict(X_test.reshape(1, nFeature * nFrames));
            print(int(labeld[label_index])),
            if int(y_pred) == 0:
                print("Hand is moving to Right")
            elif int(y_pred) == 1:
                print("Hand is moving to Left")
            elif int(y_pred) == 2:
                print("Hand is moving to Forward")
            elif int(y_pred) == 3:
                print("Hand is moving to Backward")
            elif int(y_pred) == 4:
                print(".")

            label_index += 1
            # print(y_pred)
            # conf_mat=confusion_matrix(y_test, y_pred, );
            # accu=metrics.accuracy_score(y_test, y_pred);
            # print("Accuracy:",accu,'\n')

        # y_pred = clf.predict(X_test);
        # conf_mat=confusion_matrix(y_test, y_pred, );
        # accu=metrics.accuracy_score(y_test, y_pred);
        # print("Accuracy:",accu,'\n')

    def load_model(self):
        self.clf = load('gesture.joblib')


    def realtime_inference(self, realtimeData):

        y_pred = self.clf.predict(realtimeData.reshape(1, nFeature * nFrames));
        # if y_pred
        if int(y_pred) == 0:
            print("Hand is moving to Right")
        elif int(y_pred) == 1:
            print("Hand is moving to Left")
        elif int(y_pred) == 2:
            print("Hand is moving to Forward")
        elif int(y_pred) == 3:
            print("Hand is moving to Backward")
        elif int(y_pred) == 4:
            print(".")



def main():
    # Show main menu
    mySVM = gestureRC()
    #mySVM.processData()
    #mySVM.train()
    mySVM.inference()
    # mySVM.realtime_inference(realtimeData)


if __name__ == "__main__":
    main()




"""
# How to use SVM
# Dataset:
    X: m*n matrix representing the feature, m: number of data samples, n: number of features
    y: 1*m vector representing the label, m: number of data samples

# load data
X_train = np.load("trainDataSet.npy")
y_train = np.load("label.npy")

clf = svm.SVC(kernel='linear').fit(X_train, y_train); # Train training set using svm
dump(clf, 'gesture.joblib')

clf = load('filename.joblib')

y_pred = clf.predict(X_test);
conf_mat=confusion_matrix(y_test, y_pred, );
accu=metrics.accuracy_score(y_test, y_pred);
print("Accuracy:",accu,'\n')

A link that introduces how to save the svm model to file and load the model from local file:
https://scikit-learn.org/stable/modules/model_persistence.html
"""
