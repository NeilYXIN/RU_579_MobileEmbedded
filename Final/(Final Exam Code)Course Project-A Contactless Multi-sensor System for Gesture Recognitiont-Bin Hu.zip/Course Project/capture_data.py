#!/usr/bin/env python
import RPi.GPIO as GPIO
import time
import ADC0832
import csv

ObstaclePin = 22;

def checkdist():
	GPIO.output(16, GPIO.HIGH);
	time.sleep(0.000015);
	GPIO.output(16, GPIO.LOW);
	while not GPIO.input(18):
		pass;
	t1 = time.time();
	while GPIO.input(18):
		pass;
	t2 = time.time();
	return (t2-t1)*340/2;

def init():
    GPIO.setmode(GPIO.BOARD);
    GPIO.setup(16,GPIO.OUT,initial=GPIO.LOW);
    GPIO.setup(18,GPIO.IN);
    time.sleep(2);
    ADC0832.setup();
    GPIO.setmode(GPIO.BOARD);       # Numbers GPIOs by physical location
    GPIO.setup(ObstaclePin, GPIO.IN, pull_up_down=GPIO.PUD_UP);

def loop(index):
        
    # ======= Init =======
    sampleCounter = 1;
    frameData = []
    frameDataBinary = []

    # Distance
    dist = checkdist();

    # PhotoRes
    light = ADC0832.getResult() - 80;
    if light < 0:
        light = 0;
    #if light > 100:
    #    light = 100;

    # Obstacle
    if (0 == GPIO.input(ObstaclePin)):
        isBarrier = 1
    else:
        isBarrier = 0

    # blockObstacle, blockDist, blockLight
    blockObstcle = 0;
    blockDist = 0;
    blockLight = 0;
    if dist < 1:
        blockDist = 1;
    if light > 65:
        blockLight = 1;
    curr_stat_bin = [isBarrier, blockDist, blockLight]
    curr_stat = [isBarrier, dist, light]
    
    frameDataBinary.append(curr_stat_bin)
    frameData.append(curr_stat)

    # ======= Main Loop =======            
    while True:
        opt = '.'
        time.sleep(0.03);

        last_stat = curr_stat

        last_light = light;
        light_diff = light - last_light
            
        # ======= Get data from sensors =======
        # Distance
        dist = checkdist();

        # PhotoRes
        light = ADC0832.getResult() - 80;
        if light < 0:
            light = 0;
        #if light > 100:
        #    light = 100;

        # Obstacle
        if (0 == GPIO.input(ObstaclePin)):
			#print "Barrier is detected !"
            isBarrier = 1
            #print "1";
        else:
            isBarrier = 0
            #print "0";
            
        # ======= Gesture Control =======

        # blockObstacle, blockDist, blockLight
        blockDist = 0;
        blockLight = 0;
        if dist < 1:
            blockDist = 1;
        if light > 65:
            blockLight = 1;
            
        curr_stat = [isBarrier, dist, light]
        curr_stat_bin = [isBarrier, blockDist, blockLight]
    
        frameDataBinary.append(curr_stat_bin)
        frameData.append(curr_stat)
        
        print (curr_stat_bin, curr_stat)
        sampleCounter += 1

        if sampleCounter == 50:
            folder = "courseProjData/"
            # index = "01"
            filename = folder + "swipeEmpty_" + str(index).zfill(2) + ".csv"
            with open(filename, 'w') as file:
                writer = csv.writer(file)
                for row in frameData:
                    writer.writerow(row)
            filename = folder + "swipeEmptyBin_" + str(index).zfill(2) + ".csv"
            with open(filename, 'w') as file:
                writer = csv.writer(file)
                for row in frameDataBinary:
                    writer.writerow(row)
            return


        # Block all
        #print isBarrier, dist, light
        #if isBarrier == 1 and dist < 1 and light > 65:
        #    isBlocking = 1;
        #    opt = "BLOCK ALL!!!!"
        #print opt


if __name__ == '__main__':     # Program start from here
    init();
    input('Enter to Next')
    try:
        for i in range(20):
            loop(i);
            input('Enter to Next')
    except KeyboardInterrupt:  # When 'Ctrl+C' is pressed, the child program destroy() will be  executed.
        ADC0832.destroy();
        print ('The end !');
        GPIO.cleanup();
