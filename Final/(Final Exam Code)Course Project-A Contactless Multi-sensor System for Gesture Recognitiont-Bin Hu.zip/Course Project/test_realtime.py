#!/usr/bin/env python
import RPi.GPIO as GPIO
import time
import ADC0832
import csv
import queue
import svm_bin1

import numpy as np


ObstaclePin = 22;

def checkdist():
	GPIO.output(16, GPIO.HIGH);
	time.sleep(0.000015);
	GPIO.output(16, GPIO.LOW);
	while not GPIO.input(18):
		pass;
	t1 = time.time();
	while GPIO.input(18):
		pass;
	t2 = time.time();
	return (t2-t1)*340/2;

def init():
    GPIO.setmode(GPIO.BOARD);
    GPIO.setup(16,GPIO.OUT,initial=GPIO.LOW);
    GPIO.setup(18,GPIO.IN);
    time.sleep(2);
    ADC0832.setup();
    GPIO.setmode(GPIO.BOARD);       # Numbers GPIOs by physical location
    GPIO.setup(ObstaclePin, GPIO.IN, pull_up_down=GPIO.PUD_UP);

def medfilt (x, k):
    """Apply a length-k median filter to a 1D array x.
    Boundaries are extended by repeating endpoints.
    """
    assert k % 2 == 1, "Median filter length must be odd."
    assert x.ndim == 1, "Input must be one-dimensional."
    k2 = (k - 1) // 2
    y = np.zeros ((len (x), k), dtype=x.dtype)
    y[:,k2] = x
    for i in range (k2):
        j = k2 - i
        y[j:,i] = x[:-j]
        y[:j,i] = x[0]
        y[:-j,-(i+1)] = x[j:]
        y[-j:,-(i+1)] = x[-1]
    return np.median (y, axis=1)

def loop(index):
        
    # ======= Init =======
    sampleCounter = 1;
    frameData = []
    frameDataBinary = []
    frameQueue = queue.Queue(50)

    # Distance
    dist = checkdist();

    # PhotoRes
    light = ADC0832.getResult() - 80;
    if light < 0:
        light = 0;
    #if light > 100:
    #    light = 100;

    # Obstacle
    if (0 == GPIO.input(ObstaclePin)):
        isBarrier = 1
    else:
        isBarrier = 0

    # blockObstacle, blockDist, blockLight
    blockObstcle = 0;
    blockDist = 0;
    blockLight = 0;
    if dist < 1:
        blockDist = 1;
    if light > 65:
        blockLight = 1;
    curr_stat_bin = [isBarrier, blockDist, blockLight]
    curr_stat = [isBarrier, dist, light]
    
    frameDataBinary.append(curr_stat_bin)
    frameData.append(curr_stat)

    # ======= Main Loop =======            
    while True:
        opt = '.'
        time.sleep(0.03);

        last_stat = curr_stat

        last_light = light;
        light_diff = light - last_light
            
        # ======= Get data from sensors =======
        # Distance
        dist = checkdist();

        # PhotoRes
        light = ADC0832.getResult() - 80;
        if light < 0:
            light = 0;
        #if light > 100:
        #    light = 100;

        # Obstacle
        if (0 == GPIO.input(ObstaclePin)):
			#print "Barrier is detected !"
            isBarrier = 1
            #print "1";
        else:
            isBarrier = 0
            #print "0";
            
        # ======= Gesture Control =======

        # blockObstacle, blockDist, blockLight
        blockDist = 0;
        blockLight = 0;
        if dist < 1:
            blockDist = 1;
        if light > 65:
            blockLight = 1;
            
        curr_stat = [isBarrier, dist, light]
        curr_stat_bin = [isBarrier, blockDist, blockLight]
    
        frameDataBinary.append(curr_stat_bin)
        frameData.append(curr_stat)
        
        #print (curr_stat_bin, curr_stat)
        sampleCounter += 1

	
        if frameQueue.full():
            frameQueue.get()
        frameQueue.put(curr_stat)
	
        frameList = list(frameQueue.queue)
        if (len(frameList) == 50):
            frameNparray = np.array(frameList)
            #print(frameNparray)
            frameNparray = np.reshape(frameNparray, 150)
            #frameNparray = frameNparray.reshape(150, 1)
            #np.reshape(frameNparray, 150, order='F')
            
            #flattenList = medfilt(flattenList, 3)
            print(frameNparray)

            mySVM.realtime_inference(frameNparray)
		


        # Block all
        #print isBarrier, dist, light
        #if isBarrier == 1 and dist < 1 and light > 65:
        #    isBlocking = 1;
        #    opt = "BLOCK ALL!!!!"
        #print opt
        

if __name__ == '__main__':     # Program start from here
    init();
    mySVM = svm_bin1.gestureRC()
    mySVM.load_model()
    input('Enter to Next')
    try:

        loop(1);

    except KeyboardInterrupt:  # When 'Ctrl+C' is pressed, the child program destroy() will be  executed.
        ADC0832.destroy();
        print ('The end !');
        GPIO.cleanup();
